# Bundle status

Prepared 2026-10-23 after the Case 06 superscript feasibility fix and Case 03 contrast-slot search update. This compact audit bundle contains current engine/Qwen source snapshots, relevant docs and tests, eight-case JSON diagnostics, and per-case JSON candidate outputs. It excludes rendered images, model weights, and the full Crello dataset. The visual comparison page is separate at `data/qwen_lora/engine_review_v10_surgical/review.html`. Case 06 now selects Qwen; Case 03 remains unresolved because its contrast candidates fail full-render checks.
