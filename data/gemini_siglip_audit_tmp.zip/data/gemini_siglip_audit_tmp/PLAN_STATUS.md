# Current project and training status

Prepared 2026-10-21 from the current MagiCanvas working tree. This is a temporary review bundle, not a release or a training approval. Source snapshots are in `logic/`; Qwen rendered comparisons and element asset examples are in `qwen_engine_review/`.

## Crello scan and Qwen data

- Pair-scan evidence: 23,302 rows scanned, 42,026 candidate pairs; 3,465 exact, 1,055 core, and 37,506 rejected (`evidence/pair_scan_summary.json`).
- Current Qwen summary: 1,202 train, 228 validation, and 90 test directions; 1,055 core examples are review-only. The summary records 1,060 cross-upstream-split pairs handled with family isolation, 322 mixed families reassigned, and a cap of six train directions per family. See `qwen_samples/summary.json`.
- A Qwen3-0.6B LoRA adapter has been trained and is present locally in the working repository, but its weights are intentionally not in this bundle. The Colab file is the training recipe, not proof by itself that an adapter generalizes.
- Held-out evaluation: adapter generated valid JSON with complete IDs for 85/90 examples (94.4%); base did so for 2/90 (2.2%). Geometry MAE was 0.0699 adapter versus 0.1737 base, but base geometry uses only two valid predictions, so this is not a balanced geometry comparison. See `qwen_samples/evaluation.json`.

## Current Qwen-to-engine result

- Eight held-out source/target pairs were run through the current engine with Qwen off and on. Seven Qwen proposals were returned and passed constraints; one had no valid complete proposal.
- The Qwen candidate was included in the rendered visual comparison. SigLIP selected it in one case; the other seven Qwen-on images are pixel-identical to Qwen-off.
- All eight on/off renders completed with zero renderer warnings. Per-case diagnostics and normalized target geometry errors are in `qwen_engine_review/manifest.json`; rendered images and the arrow-key viewer are alongside it.
- In the one Qwen-selected case, target geometry MAE was 0.06021 for Qwen-on versus 0.04771 for Qwen-off. SigLIP preferred the Qwen render, but geometric closeness did not improve. This is ambiguous evidence, not a Qwen win claim.
- Current Qwen prompts are text-only and do not include image asset IDs or pixels. The converted IDs are generic `element_###.png` names. `qwen_engine_review/asset_context/` copies actual source/target assets and contact sheets so visual roles can be inspected; no semantic labels have been invented.

## SigLIP status

- No SigLIP ranker has been trained. The local trainer uses human approvals and family-level splitting; previous smoke/guard results are summarized in `evidence/`.
- A Crello preview indicates what the dataset depicts but does not prove local renderer fidelity or that every design is a useful target. Continue to treat previews as reference images and require local fidelity checks before generating positives.
- Engine output is not automatically a negative example: some adaptations have no measurable defect, and the current eight-case Qwen review demonstrates that metrics can disagree.

## Review boundaries

The bundle includes copied source files, small Qwen JSONL samples, eight current rendered cases, and image assets for those cases. It excludes the complete Crello assets/previews, full pair manifest, fonts, and model weights. Do not infer that a small visual batch validates the whole dataset. Distinguish executable code, trustworthy labels, and justified training as separate claims.
