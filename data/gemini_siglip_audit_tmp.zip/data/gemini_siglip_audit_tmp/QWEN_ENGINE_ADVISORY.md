# Gemini review: Qwen engine v10 Case 06 / Case 03 follow-up

Audit the copied engine code and regenerated eight-case v10 diagnostics. Do not edit the project or assume any example ID has special handling. Separate code-path verification from what this eight-case run demonstrates. The visual viewer is separate at `data/qwen_lora/engine_review_v10_surgical/review.html`; this bundle intentionally contains no images.

## Changes to verify

1. `logic/engine/qwen_refine.py::anchor_superscripts` now tightens a linked one-line anchor text frame to its measured glyph width, preserves the visible glyph origin, and places the satellite at least 4 px after the anchor's measured visible right edge. This prevents oversized model text frames from making a visually clean `$49`/`99` lockup infeasible. The source design remains unmodified.
2. Contrast candidate generation now includes `.17 * canvas_width` and `.22 * canvas_width` as horizontal positions in both the local group-slot and whole-lockup search. All candidates still pass feasibility and actual full-render contrast checks before ranking.
3. The earlier behaviors remain: no hardcoded IDs, no `renderer/converter/` changes, and Qwen candidates are rerendered and checked for geometry, text contrast, and visibility.

## Regenerated v10 evidence

- Eight cases rendered into the viewer and manifest.
- Case 06 (`59524ced95a7a863ddcde0b2__to__58b4351a95a7a863ddcc9d62`, 1080x1080) now selects `qwen-local-refined`. The Qwen family is feasible; its candidates have zero layout-defect cost and no low-contrast or invisible text. The superscript anchor frame is reduced to the measured glyph width and the satellite has a 4 px visible-ink gap.
- Case 03 (`59bb916d1350e83293011005__to__592e7d0a95a7a863ddcdaa18`, 851x315) still selects `safe-grid`. The new `.17` and `.22` positions are generated, but no rendered Qwen contrast repair clears the full-render contrast guard on every affected white text element. Treat Case 03 as unresolved; do not infer the requested slot additions alone solved it.
- The proposal that Case 06 was excluded only by busy-background objective differences was not supported by the old v10 manifest: it had a large layout-defect cost from raw unit-box collision. Fixing the superscript text frame removed that defect.
- Focused validation: `tests/test_qwen_pipeline.py` passed (10 tests).

## Review requests

Independently verify the superscript frame-tightening geometry and the Case 06 feasibility result. Check whether Case 03's new horizontal slots reach the intended dark region and why the full-render contrast gate still rejects those candidates. Recommend any general fix only if supported by the render evidence; avoid tuning by example ID. Do not recommend changes to the Adobe starter renderer or hardcoded example IDs.
