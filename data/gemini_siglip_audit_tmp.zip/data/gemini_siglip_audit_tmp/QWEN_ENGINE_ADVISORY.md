# Qwen layout model: current evidence and question for review

## Current behavior

- Qwen3-0.6B with the local LoRA adapter predicts geometry for the source elements. It does not render the design.
- `engine/resize.py` runs the proposal through shared-stack preservation and hard layout checks, keeps Qwen's feasible geometry as a separate candidate, and compares rendered candidates. Qwen can be selected only if it remains valid/readable and SigLIP prefers it by the configured margin while its objective cost remains in the comparison band.
- The current prompt is text-only: element ID, type, source geometry, z-order, rotation, optional group, and text/font/alignment fields. It does not include image asset IDs or image pixels.
- Converted image `asset_id` values generally look like `assets/<template-id>/element_###.png`; those names identify storage order, not semantic content. Inspect the copied asset contact sheets before deciding filename context is useful.

## Latest evidence

- Eight held-out examples were rerendered from the current code. Seven produced a valid Qwen proposal and passed constraints; one returned no valid complete proposal.
- Qwen was selected in one of eight cases. Seven Qwen-on images are pixel-identical to Qwen-off because another candidate won or Qwen had no proposal.
- All eight on/off renderer outputs had zero renderer warnings.
- In the one selected case, final geometry MAE against the held-out target was 0.06021 with Qwen versus 0.04771 with Qwen off. SigLIP selected the Qwen render, but the geometric metric did not improve. This is a useful disagreement to inspect, not proof that either selection is right.
- Held-out adapter JSON validity was 85/90 (94.4%), compared with 2/90 (2.2%) for the base model. Reported geometry MAE was 0.0699 adapter versus 0.1737 base; the base figure uses only two valid predictions, so that comparison is weak.
- The Qwen JSONL was derived from exact multi-size template pairs. It teaches mapping source layout/content/geometry to paired target geometry; it does not directly teach semantic image recognition from pixels.

## What we want your independent judgment on

The user believes the heuristic engine is not strong enough to make good positional decisions and that a model is needed both to arrange content and to understand what visual assets mean. Evaluate that premise against the supplied code and samples. Recommend whether to:

1. Give the current text Qwen better context (and exactly which fields are supported by the data);
2. Add grounded asset descriptions/OCR or image embeddings to text prompts;
3. Train/fine-tune a multimodal layout model that consumes source previews or element crops;
4. Keep Qwen as a candidate generator but change the engine's ranking/repair policy; or
5. Use a different staged combination.

For every recommendation, state the evidence needed, the smallest pilot, possible failure modes, and how to keep the original starter runner's hard contract intact. In particular, tell us whether the generic `element_###.png` path basename contributes any useful semantics, and whether asset pixels should be paired with IDs/boxes and target coordinates rather than converted into speculative text labels.
