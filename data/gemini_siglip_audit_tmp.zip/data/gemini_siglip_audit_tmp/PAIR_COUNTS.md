# Current pair/data counts

Counts copied from the current generated manifests on 2026-10-21. They describe scanner classifications and exporter outputs, not a claim that every pair is a good learning target.

## Verified-pair scan

- Exact: 3,465
- Core: 1,055
- Rejected: 37,506
- Total pair records: 42,026

## Qwen export

- Train: 1,170 exact directions
- Validation: 276 exact directions
- Test: 180 exact directions
- Core review only: 1,055
- Skipped for changed non-background image aspect: 1,432
- Train examples removed by family cap: 3,872
- Cross-upstream-split pairs handled under connected-family isolation: 1,060; connected families reassigned: 327

See `evidence/qwen_summary.json` and `evidence/pair_scan_summary.json` for machine-readable summaries.

## SigLIP current evidence

- Review page: 122 pairs; 25 candidates rerendered with current engine, 0 failures.
- One-pair smoke: 1 candidate rendered; 0 accepted negative labels; 1 candidate had no measured defect; 0 failures.
- The smoke test is not a representative dataset and is not training evidence. No SigLIP head was trained.
