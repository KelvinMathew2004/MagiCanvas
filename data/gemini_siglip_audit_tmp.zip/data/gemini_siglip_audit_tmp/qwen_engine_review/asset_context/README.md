# Source and target element asset context

Each pair directory contains `source_design.json`, `target_design.json`, copied image assets under `source/` and `target/`, plus `asset_contact_sheet.jpg` showing the isolated image assets labeled by element ID and z-index.

The design JSON `asset_id` values still use the original generic `assets/<template-id>/element_###.png` names. Those names are identifiers only; they do not say whether an image is a hero, badge, background, ribbon, bullet, or other role. Use the actual pixels and neighboring text/layer order to infer role, and mark ambiguous interpretations as ambiguous. No semantic labels were added to the source data.
