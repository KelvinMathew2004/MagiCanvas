# Independent review request: making Qwen useful for design resizing

This is a refreshed, temporary review bundle copied from the current MagiCanvas working tree. Start with `QWEN_ENGINE_ADVISORY.md`. Use the code snapshots under `logic/` as the source of truth, then inspect the current rendered comparisons and diagnostics under `qwen_engine_review/`. Do not edit this bundle or assume prior audit claims are correct. Separate definite bugs, evidence-based conclusions, and design choices.

## Main question

The current resize engine's heuristic layouts can be poor. We need the learned model to contribute meaningful positioning and to understand what visual elements represent. Please recommend the smallest reliable path to make Qwen better at resizing designs while preserving element IDs/content and satisfying the starter runner's hard requirements. Assess whether asset names/paths are useful context, and what visual/context information would actually help when those names are generic.

Please inspect together:

- `logic/engine/qwen_prompt.py`, `logic/engine/qwen_seed.py`, `logic/engine/resize.py`, and `logic/engine/main.py`.
- `logic/scripts/prepare_qwen_training.py`, `logic/scripts/evaluate_qwen_adapter.py`, and `logic/docs/QWEN_LORA_COLAB.md`.
- `qwen_engine_review/review.html`, its `manifest.json`, and the eight Qwen on/off/target/preview comparisons.
- `qwen_engine_review/asset_context/asset_map.json`, the source/target JSONs, and `asset_contact_sheet.jpg` files. These show the images available for each source/target element.
- `qwen_samples/summary.json`, `qwen_samples/evaluation.json`, and the bounded JSONL samples.

## Questions to answer

1. Trace the live inference path. Is Qwen being used as a genuine layout predictor or only as a candidate seed? Which constraints, repairs, energy terms, and SigLIP gates can alter or reject its geometry? Identify current paths that could discard useful predictions, but distinguish harmful behavior from safeguards needed for hard validity.
2. The latest eight-case review has seven valid Qwen proposals; one was selected, so seven rendered Qwen-on images remain identical to Qwen-off. For each case, use the diagnostics and images to explain the outcome. Do not claim that a higher Qwen score proves the visual output is better.
3. The Qwen prompt currently omits image asset IDs and visual contents. The converted asset paths are normally generic names like `assets/<template>/element_003.png`, not semantic labels. Would passing those strings help at all? Could Crello metadata, OCR, object/role labels, thumbnails, source preview crops, or a multimodal model supply useful context? Discuss error risks from guessed semantics and how to validate annotations before using them in training.
4. The current adapter evaluation reports 85/90 valid JSON+complete-ID outputs (94.4%) versus 2/90 for base; geometry MAE is 0.0699 for adapter and 0.1737 for base, but base geometry is measured on only two valid outputs. Explain which conclusions are supported and what evaluation is still needed.
5. Exact multi-size pairs supervise target geometry but may not teach semantic object recognition. Is the current data sufficient for positioning when the model sees only text/geometry, and what is the minimum data/prompt change needed to teach asset roles?
6. Recommend a staged experiment that can be run by a first-time model trainer: one small sample, measurable success criteria, comparison against engine baseline, hard-rule checks, and rollback criteria. Say explicitly what should not be changed or trained until the pilot passes.

Do not recommend blindly trusting Qwen, removing on-canvas/non-overlap checks, automatically treating all previews as quality labels, or creating semantic labels from filenames without evidence. If a multimodal alternative is preferable, compare runtime size, inference cost, Docker/offline feasibility, and training-data requirements against the current local Qwen3-0.6B plus SigLIP setup. Cite primary/official sources for version-sensitive model/tool claims.

## Bundle scope

The bundle contains code snapshots, small Qwen JSONL samples, eight current rendered comparisons, and copied image assets for those sample pairs. It does not contain the full Crello dataset, complete pair manifest, fonts, or model weights. `asset_context/` copies are supplied so element names can be compared with the actual image contents; they are not semantic annotations. Treat the example review as a small pilot, not proof of general quality.
