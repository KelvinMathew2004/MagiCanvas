# Temporary Gemini review bundle

Start with `QWEN_ENGINE_ADVISORY.md`, then inspect `logic/engine/`, `logic/tests/`, and `qwen_engine_review_v10/`. The files under `logic/` are snapshots; do not edit them as project files.

The v10 manifest contains rendered diagnostics and selected-candidate evidence. The JSON outputs preserve model and engine geometry without embedding image assets. The local visual viewer is at `data/qwen_lora/engine_review_v10_surgical/review.html` and is not included in this bundle. Model weights, rendered images, and the full Crello dataset are excluded.
