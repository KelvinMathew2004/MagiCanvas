# Final v11 engine and Qwen training preflight

Review this bundle as an independent audit before the next LoRA run. The active
project code is snapshotted under `logic/`; do not edit the project through this
bundle.

## Changes to audit

1. In `logic/engine/qwen_refine.py`, superscript anchoring preserves the
   measured visible glyph width and tightens the hero's raw frame to leave a
   two-pixel gap from the superscript frame. Check both raw-box overlap and
   visible-glyph placement.
2. In `logic/engine/resize.py`, a source-linked stack uses one uniform scale;
   tracked text follows the scaled/fitted font size. The SigLIP busy-background
   tolerance is limited to Qwen candidates with no weak or invisible text,
   zero layout-defect cost, and at least 4.5 lower-quintile contrast on every
   checked text. The heuristic must have identical element geometry and gain
   its lower busyness cost only by shrinking display text.
3. In `logic/engine/qwen_refine.py`, contrast repair can expand a source-backed
   `fit: "cover"` strip to cover a padded text span and tests lockup placements
   at 17% and 21% of canvas width. Confirm the candidates remain subject to the
   ordinary feasibility, overlap, and contrast checks.

No example IDs are hardcoded. `renderer/converter/` is unchanged.

## Evidence to inspect

- Open `qwen_v10_v11_comparison/matched_pairs.html` first. It compares the same
  source→target pair IDs across versions. `GEMINI_REVIEW_NOTES.md` records the
  pixel comparison and renderer-mode caveat for the older v10 batch.
- The complete eight-case pages and selected rendered assets are in the
  `v10/` and `v11/` subfolders.
- Inspect the refreshed v11 `manifest.json`, candidate JSON, and diagnostics
  under `qwen_engine_review_v11/`.
- Review focused regressions in `logic/tests/test_qwen_pipeline.py`.
- The stack-preserved sibling did not trigger in this eight-case batch; its
  positive path is covered by targeted tests, but this sample has no real render
  demonstrating its visual effect.

## Training preflight

The fixes are inference-time geometry, candidate repair, and ranking logic.
They do not change `scripts/prepare_qwen_training.py`, the v2 prompt, target
JSON schema, target coordinates, or text labels. Existing v2 JSONL therefore
does not need regeneration for these fixes. The current response-only mask
inspection and dynamic assistant marker are in `logic/docs/QWEN_LORA_COLAB.md`.
Please flag any specific reason the training data or masking code should change
before training; do not recommend retraining solely because inference logic
changed.

The local source-capped v2 files contain 2,013 train, 309 validation, and 89
test rows across 295, 35, and 21 families. Their test template IDs have no
overlap with the currently trained v2 adapter's train or validation IDs. The
updated `logic/scripts/evaluate_qwen_adapter.py` can compare two separate
adapter directories through the full engine and reports post-constraint
geometry MAE, family-macro MAE, Qwen-family wins, raw proposal validity, and
hard-check rates. Please check that these measures support the proposed
keep-or-reject rule without treating a small visual batch as a substitute for
the 89-case held-out comparison.

## Requested response

Report concrete correctness issues, missing regression coverage, and any reason
the v2 training workflow is not ready. Distinguish verified defects from
speculation. Do not propose case-specific IDs or edits to `renderer/converter/`.
