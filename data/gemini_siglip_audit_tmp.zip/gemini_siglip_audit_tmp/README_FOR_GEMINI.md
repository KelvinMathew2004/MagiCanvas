# Gemini final review bundle

Start with `QWEN_ENGINE_ADVISORY.md`. For visual evidence, open
`qwen_v10_v11_comparison/matched_pairs.html`, then the full batch viewers in
the `v10/` and `v11/` folders. Review the v11 manifest and candidate JSON in
`qwen_engine_review_v11/`, then the copied code and focused tests under `logic/`.

The v11 review records its renderer mode and includes the original dataset
previews plus rendered candidate images. The older v10 run did not record its
renderer flag; the comparison notes identify this limitation. Model weights
and the full Crello dataset are excluded. All files are temporary audit copies.
