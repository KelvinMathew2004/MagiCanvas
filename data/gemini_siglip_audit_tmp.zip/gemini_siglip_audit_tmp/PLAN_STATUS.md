# Bundle status

Prepared 2026-10-23 as the final v11 pretraining audit snapshot. It contains
current Qwen/resize source and docs, focused tests, an eight-case v11 review
with dataset previews and rendered candidates, and exact-pair v10/v11 evidence.
It excludes model weights and the full Crello dataset.

The source-capped v2 export contains 2,013 train / 309 validation / 89 test
rows in 295 / 35 / 21 isolated template families. Its test template IDs do not
overlap the current adapter's training or validation template IDs. The updated
evaluator compares separate adapters through the full engine and reports
post-constraint geometry, family-macro geometry, Qwen-family wins, and hard
checks.

The active v11 review uses the starter-renderer path with the dataset-only
tight-text adjustment disabled; each manifest row records that mode. The v10
manifest predates this metadata. The pair comparison only supports conclusions
for exact shared source→target IDs.

The three v11 updates are inference-time changes. The prepared v2 target JSONL,
prompt, coordinates, and text labels are unchanged. The Colab guide includes
response-only masking and an assertion-based decoded-label inspection.
