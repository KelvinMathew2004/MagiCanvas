# v10 vs v11 review bundle

Open matched_pairs.html for exact source→target pairs shared by both versions. Full eight-case batch viewers and rendered images are in v10/ and v11/.

## Findings

- The batches contain 8 v10 cases and 8 v11 cases; 2 exact source→target pair IDs overlap.
- The six non-overlapping cases in each batch cannot support a by-row regression claim.
- Pixel comparison on shared pairs: preview 0/2 differ, target 1/2 differ, raw 1/2 differ, micro 1/2 differ, base 1/2 differ, adapter 1/2 differ.
- The refreshed v11 manifest records renderer_mode: starter_renderer_unadjusted per case. The older v10 manifest did not record its builder flag, so local-render differences may include renderer-mode effects.
- These are small, repeatedly inspected examples. Treat them as diagnostic evidence, not a generalization result.

## Audit question

Assess the three current v11 fixes in QWEN_ENGINE_ADVISORY.md. For image differences, distinguish engine geometry/ranking changes from renderer mode and source/target differences. Review current source snapshots, focused tests, and the masked-label inspection in the Colab guide before recommending training-data changes.
